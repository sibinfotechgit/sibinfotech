export const BACKEND_URL = 'https://www.sibinfotech.com/live-node-api/';
export const API_URL = 'https://www.sibinfotech.com/live-node-api/api/';
export const API_TOKEN = 'FgRCHG4OVv8Z1BcrjExKJcqspvTsUTCe';

// export const BASE_URL = 'https://www.sibinfotech.com/';
export const BASE_URL = 'https://www.sibinfotech.com/';
